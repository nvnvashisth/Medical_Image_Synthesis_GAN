#### Directory structure on new dataset needed for training and testing:

```
./Dataset-name/trainA
./Dataset-name/trainB
./Dataset-name/testA
./Dataset-name/testB
```
